from .otBase import BaseTTXConverter


class table_B_A_S_E_(BaseTTXConverter):
	pass
